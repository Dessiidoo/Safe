# Overview

Safelite Global Careers is a premium international job matching website that connects everyday people with relocation opportunities abroad. The platform features protected job listings behind a $99 retainer paywall, three subscription tiers ($500, $2,000, $5,000), and daily job updates from expat forums. The service targets people with little to no experience seeking international work opportunities with full visa support and relocation assistance.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **Styling**: Tailwind CSS with shadcn/ui component library for consistent UI components
- **State Management**: TanStack Query for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **UI Components**: Radix UI primitives wrapped in custom components for accessibility and consistency

## Backend Architecture
- **Server**: Express.js with TypeScript for RESTful API endpoints
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Storage Strategy**: Dual storage implementation with in-memory storage for development and database storage for production
- **Session Management**: Express sessions with PostgreSQL session store

## Data Models
The application uses a well-defined schema with the following core entities:
- **Users**: Customer profiles with subscription status, payment tracking, and profile completion status
- **Job Listings**: International job opportunities with location, salary, visa sponsorship, and tier requirements
- **Job Applications**: User applications to specific job listings with status tracking
- **Subscription Tiers**: Service packages (Basic $500, Premium $2000, VIP $5000) with feature sets and job limits

## API Design
RESTful endpoints following standard conventions:
- User management (`/api/users`)
- Job listings (`/api/job-listings`)
- Subscription management (`/api/subscription-tiers`)
- Payment processing (`/api/create-payment-intent`, `/api/create-subscription`)
- Protected job access with authentication middleware

## Authentication & Security
- Password-based authentication system
- Session-based user management
- Input validation using Zod schemas
- Environment-based configuration for security settings

# External Dependencies

## Database & ORM
- **Neon Database**: Serverless PostgreSQL database hosting
- **Drizzle ORM**: Type-safe database operations and migrations
- **connect-pg-simple**: PostgreSQL session store for Express

## UI & Styling
- **Tailwind CSS**: Utility-first CSS framework
- **Radix UI**: Unstyled, accessible UI primitives
- **Lucide React**: Icon library for consistent iconography
- **shadcn/ui**: Pre-built component library built on Radix UI

## Development & Build Tools
- **Vite**: Fast frontend build tool and dev server
- **TypeScript**: Type safety across the entire application
- **ESBuild**: Fast JavaScript bundler for production builds
- **Replit Integration**: Development environment integration and deployment

## Fonts & Assets
- **Google Fonts**: Inter for body text, Orbitron for headings, and additional specialized fonts
- **Unsplash**: Stock photography for mystery scenarios and character avatars