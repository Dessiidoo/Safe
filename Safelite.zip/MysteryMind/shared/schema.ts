import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, timestamp, jsonb, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  firstName: text("first_name"),
  lastName: text("last_name"),
  email: text("email").notNull().unique(),
  phone: text("phone"),
  subscriptionTier: text("subscription_tier"), // null, 'basic', 'premium', 'vip'
  stripeCustomerId: text("stripe_customer_id"),
  stripeSubscriptionId: text("stripe_subscription_id"),
  hasRetainerAccess: boolean("has_retainer_access").default(false),
  retainerPaid: boolean("retainer_paid").default(false),
  profileCompleted: boolean("profile_completed").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const jobApplications = pgTable("job_applications", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  email: text("email").notNull(),
  phone: text("phone").notNull(),
  currentCountry: text("current_country").notNull(),
  preferredCountries: text("preferred_countries").array().notNull(),
  workExperience: text("work_experience").notNull(),
  education: text("education").notNull(),
  languages: text("languages").array().notNull(),
  skills: text("skills").array().notNull(),
  hasPassport: boolean("has_passport").notNull(),
  willingToRelocate: boolean("willing_to_relocate").notNull(),
  additionalInfo: text("additional_info"),
  status: text("status").notNull().default("pending"), // pending, approved, rejected
  createdAt: timestamp("created_at").defaultNow(),
});

export const jobListings = pgTable("job_listings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  company: text("company").notNull(),
  location: text("location").notNull(),
  country: text("country").notNull(),
  description: text("description").notNull(),
  requirements: text("requirements").array().notNull(),
  benefits: text("benefits").array().notNull(),
  salary: text("salary"),
  jobType: text("job_type").notNull(), // full-time, part-time, contract
  experienceLevel: text("experience_level").notNull(), // entry, mid, senior
  visaSponsorship: boolean("visa_sponsorship").default(false),
  remote: boolean("remote").default(false),
  featured: boolean("featured").default(false),
  requiredTier: text("required_tier").notNull().default("basic"), // basic, premium, vip
  isActive: boolean("is_active").default(true),
  externalUrl: text("external_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const subscriptionTiers = pgTable("subscription_tiers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(), // Basic, Premium, VIP
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  currency: text("currency").default("USD"),
  interval: text("interval").notNull(), // month, year
  features: text("features").array().notNull(),
  jobsPerMonth: integer("jobs_per_month").notNull(),
  isActive: boolean("is_active").default(true),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertJobApplicationSchema = createInsertSchema(jobApplications).omit({
  id: true,
  createdAt: true,
});

export const insertJobListingSchema = createInsertSchema(jobListings).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type JobApplication = typeof jobApplications.$inferSelect;
export type JobListing = typeof jobListings.$inferSelect;
export type SubscriptionTier = typeof subscriptionTiers.$inferSelect;
export type InsertJobApplication = z.infer<typeof insertJobApplicationSchema>;
export type InsertJobListing = z.infer<typeof insertJobListingSchema>;
