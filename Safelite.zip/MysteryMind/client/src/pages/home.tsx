import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { Globe, MapPin, Shield, CheckCircle, Briefcase, Users, Award, Sparkles } from "lucide-react";

export default function Home() {
  const { data: featuredJobs, isLoading: jobsLoading } = useQuery({
    queryKey: ["/api/jobs/featured"],
  });

  const { data: subscriptionTiers, isLoading: tiersLoading } = useQuery({
    queryKey: ["/api/subscription-tiers"],
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-gray-100">
      {/* Header */}
      <header className="relative z-50 p-4 lg:p-6 bg-white/80 backdrop-blur-sm border-b border-blue-100">
        <nav className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-blue-800 rounded-xl flex items-center justify-center shadow-lg">
              <div className="relative">
                <Globe className="text-white w-7 h-7" />
                <div className="absolute top-1 left-1 w-2 h-2 bg-yellow-400 rounded-full animate-pulse"></div>
              </div>
            </div>
            <div>
              <span className="text-2xl font-bold text-blue-900" style={{ fontFamily: 'var(--font-orbitron)' }}>
                Safelite Global
              </span>
              <div className="text-sm text-blue-600 -mt-1">Careers</div>
            </div>
          </div>
          
          <div className="hidden md:flex items-center space-x-8">
            <a href="#pricing" className="hover:text-blue-600 transition-colors text-gray-700">Pricing</a>
            <a href="#jobs" className="hover:text-blue-600 transition-colors text-gray-700">Jobs</a>
            <a href="#process" className="hover:text-blue-600 transition-colors text-gray-700">How It Works</a>
            <Link href="/subscribe">
              <Button className="bg-blue-600 hover:bg-blue-700 shadow-lg" data-testid="button-get-started">
                Get Started
              </Button>
            </Link>
          </div>
          
          <Button variant="ghost" className="md:hidden" data-testid="button-menu">
            <span className="sr-only">Menu</span>
            ☰
          </Button>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="relative px-4 py-16 lg:py-24 bg-gradient-to-br from-blue-600 to-blue-800 text-white">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl lg:text-6xl font-bold mb-6" style={{ fontFamily: 'var(--font-orbitron)' }}>
                Your Dream Job <br/>
                <span className="text-yellow-400">Abroad</span> Awaits
              </h1>
              <p className="text-xl text-blue-100 mb-8 max-w-2xl">
                Connect with international employers seeking everyday people like you. 
                No experience required - we help you relocate to exciting opportunities worldwide.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 mb-8">
                <Link href="/subscribe">
                  <Button 
                    size="lg" 
                    className="bg-yellow-500 hover:bg-yellow-400 text-blue-900 font-bold px-8 py-4 text-lg shadow-lg"
                    data-testid="button-start-journey"
                  >
                    <Sparkles className="mr-2 w-5 h-5" />
                    Start Your Journey
                  </Button>
                </Link>
                <Button 
                  variant="outline" 
                  size="lg" 
                  className="border-blue-200 text-blue-100 hover:bg-blue-700 px-8 py-4 text-lg"
                  data-testid="button-learn-more"
                >
                  <Globe className="mr-2 w-5 h-5" />
                  Learn More
                </Button>
              </div>

              <div className="flex items-center space-x-6 text-blue-100">
                <div className="flex items-center space-x-2">
                  <Shield className="w-5 h-5 text-yellow-400" />
                  <span>Protected Job Listings</span>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-5 h-5 text-yellow-400" />
                  <span>Visa Support</span>
                </div>
              </div>
            </div>

            <div className="relative">
              <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-blue-400/30">
                <div className="text-center mb-6">
                  <div className="w-16 h-16 bg-yellow-400 rounded-full flex items-center justify-center mx-auto mb-4">
                    <MapPin className="w-8 h-8 text-blue-900" />
                  </div>
                  <h3 className="text-xl font-bold mb-2">Premium Access Required</h3>
                  <p className="text-blue-100">All job listings are protected to prevent theft by competitors</p>
                </div>
                
                <div className="space-y-3 mb-6">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-gray-400 rounded blur-sm"></div>
                    <div className="flex-1 space-y-1">
                      <div className="h-4 bg-gray-400 rounded blur-sm"></div>
                      <div className="h-3 bg-gray-400 rounded blur-sm w-3/4"></div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-gray-400 rounded blur-sm"></div>
                    <div className="flex-1 space-y-1">
                      <div className="h-4 bg-gray-400 rounded blur-sm"></div>
                      <div className="h-3 bg-gray-400 rounded blur-sm w-2/3"></div>
                    </div>
                  </div>
                </div>
                
                <div className="bg-yellow-400 text-blue-900 p-4 rounded-lg text-center font-bold">
                  $99 Retainer Fee + Monthly Subscription
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-blue-600 mb-2" data-testid="stat-job-placements">2,500+</div>
              <div className="text-gray-600">Successful Placements</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-blue-600 mb-2" data-testid="stat-countries">45</div>
              <div className="text-gray-600">Countries Available</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-blue-600 mb-2" data-testid="stat-employers">1,200+</div>
              <div className="text-gray-600">Partner Employers</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-blue-600 mb-2" data-testid="stat-visa-success">94%</div>
              <div className="text-gray-600">Visa Success Rate</div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 bg-gray-50" id="process">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4" style={{ fontFamily: 'var(--font-orbitron)' }}>
              How It Works
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Simple 4-step process to land your international dream job
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                step: "1",
                title: "Pay Retainer",
                description: "Secure your access with a $99 retainer fee to unlock protected job listings",
                icon: Shield,
                color: "bg-blue-500"
              },
              {
                step: "2", 
                title: "Choose Plan",
                description: "Select the subscription tier that matches your career goals and budget",
                icon: Award,
                color: "bg-green-500"
              },
              {
                step: "3",
                title: "Apply to Jobs",
                description: "Browse exclusive opportunities and apply to positions that interest you",
                icon: Briefcase,
                color: "bg-purple-500"
              },
              {
                step: "4",
                title: "Get Matched",
                description: "We handle visa support and relocation assistance for successful matches",
                icon: Users,
                color: "bg-orange-500"
              }
            ].map((step, index) => (
              <Card key={index} className="relative bg-white shadow-lg border-0 hover:shadow-xl transition-all">
                <CardContent className="p-6 text-center">
                  <div className={`w-16 h-16 ${step.color} rounded-full flex items-center justify-center mx-auto mb-4 text-white font-bold text-xl`}>
                    {step.step}
                  </div>
                  <step.icon className="w-8 h-8 mx-auto mb-4 text-gray-600" />
                  <h3 className="text-xl font-semibold mb-3 text-gray-900" data-testid={`text-step-title-${index}`}>
                    {step.title}
                  </h3>
                  <p className="text-gray-600" data-testid={`text-step-description-${index}`}>
                    {step.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-16 bg-white" id="pricing">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4" style={{ fontFamily: 'var(--font-orbitron)' }}>
              Choose Your Plan
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto mb-8">
              Unlock international job opportunities with our premium subscription tiers
            </p>
            <div className="bg-yellow-100 border border-yellow-400 rounded-lg p-4 max-w-md mx-auto">
              <p className="text-yellow-800 font-semibold">🔐 $99 Retainer Fee Required</p>
              <p className="text-yellow-700 text-sm">One-time fee to access protected job listings</p>
            </div>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {tiersLoading ? (
              Array.from({ length: 3 }).map((_, i) => (
                <Card key={i} className="border shadow-lg">
                  <CardContent className="p-8">
                    <Skeleton className="h-8 w-24 mb-4" />
                    <Skeleton className="h-12 w-32 mb-6" />
                    <div className="space-y-2 mb-6">
                      {Array.from({ length: 4 }).map((_, j) => (
                        <Skeleton key={j} className="h-4 w-full" />
                      ))}
                    </div>
                    <Skeleton className="h-12 w-full" />
                  </CardContent>
                </Card>
              ))
            ) : (
              subscriptionTiers?.map((tier: any, index: number) => (
                <Card 
                  key={tier.id} 
                  className={`border shadow-lg ${index === 1 ? 'ring-2 ring-blue-600 relative scale-105' : 'hover:shadow-xl'} transition-all`}
                >
                  {index === 1 && (
                    <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                      <div className="bg-blue-600 text-white px-4 py-2 rounded-full text-sm font-bold">
                        MOST POPULAR
                      </div>
                    </div>
                  )}
                  <CardContent className="p-8">
                    <div className="text-center mb-8">
                      <h3 className="text-2xl font-bold text-gray-900 mb-2" data-testid={`text-tier-name-${tier.id}`}>
                        {tier.name}
                      </h3>
                      <div className="mb-4">
                        <span className="text-4xl font-bold text-blue-600" data-testid={`text-tier-price-${tier.id}`}>
                          ${tier.price}
                        </span>
                        <span className="text-gray-600">/{tier.interval}</span>
                      </div>
                      <div className="text-sm text-gray-500 mb-6" data-testid={`text-tier-jobs-${tier.id}`}>
                        Up to {tier.jobsPerMonth} job applications per month
                      </div>
                    </div>
                    
                    <ul className="space-y-3 mb-8">
                      {tier.features.map((feature: string, featureIndex: number) => (
                        <li 
                          key={featureIndex} 
                          className="flex items-center space-x-3"
                          data-testid={`feature-${tier.id}-${featureIndex}`}
                        >
                          <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                          <span className="text-gray-700">{feature}</span>
                        </li>
                      ))}
                    </ul>
                    
                    <Link href={`/subscribe?tier=${tier.name.toLowerCase()}`}>
                      <Button 
                        className={`w-full ${index === 1 
                          ? 'bg-blue-600 hover:bg-blue-700 text-white' 
                          : 'bg-gray-100 hover:bg-gray-200 text-gray-900'
                        }`}
                        size="lg"
                        data-testid={`button-select-plan-${tier.id}`}
                      >
                        Select {tier.name}
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </div>
      </section>

      {/* Featured Jobs Preview */}
      <section className="py-16 bg-gray-50" id="jobs">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-4" style={{ fontFamily: 'var(--font-orbitron)' }}>
              Featured Opportunities
            </h2>
            <p className="text-xl text-gray-600">Sample of international job opportunities waiting for you</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {jobsLoading ? (
              Array.from({ length: 2 }).map((_, i) => (
                <Card key={i} className="bg-white shadow-lg">
                  <CardContent className="p-6">
                    <Skeleton className="h-6 w-3/4 mb-4" />
                    <Skeleton className="h-4 w-1/2 mb-2" />
                    <Skeleton className="h-4 w-full mb-4" />
                    <div className="space-y-2">
                      {Array.from({ length: 3 }).map((_, j) => (
                        <Skeleton key={j} className="h-4 w-full" />
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : featuredJobs && featuredJobs.length > 0 ? (
              featuredJobs.slice(0, 2).map((job: any) => (
                <Card key={job.id} className="bg-white shadow-lg hover:shadow-xl transition-all">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="text-xl font-bold text-gray-900 mb-2" data-testid={`text-job-title-${job.id}`}>
                          {job.title}
                        </h3>
                        <p className="text-gray-600 mb-1" data-testid={`text-job-company-${job.id}`}>
                          {job.company}
                        </p>
                        <div className="flex items-center space-x-2 text-gray-500">
                          <MapPin className="w-4 h-4" />
                          <span data-testid={`text-job-location-${job.id}`}>{job.location}, {job.country}</span>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-lg font-bold text-blue-600" data-testid={`text-job-salary-${job.id}`}>
                          {job.salary}
                        </div>
                        {job.visaSponsorship && (
                          <div className="text-sm text-green-600 font-semibold">Visa Sponsored</div>
                        )}
                      </div>
                    </div>
                    
                    <p className="text-gray-700 mb-4" data-testid={`text-job-description-${job.id}`}>
                      {job.description}
                    </p>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4 text-sm text-gray-600">
                        <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded">
                          {job.experienceLevel}
                        </span>
                        <span className="bg-green-100 text-green-800 px-2 py-1 rounded">
                          {job.jobType}
                        </span>
                      </div>
                      <div className="text-sm text-gray-500">
                        Requires: {job.requiredTier} tier
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <div className="col-span-full text-center py-12">
                <Briefcase className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">No featured jobs available at the moment</p>
              </div>
            )}
          </div>
          
          <div className="text-center mt-8">
            <p className="text-gray-600 mb-4">Ready to access thousands more opportunities?</p>
            <Link href="/subscribe">
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700" data-testid="button-unlock-all-jobs">
                Unlock All Jobs
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="px-4 py-8 bg-blue-900 text-white">
        <div className="max-w-7xl mx-auto text-center">
          <div className="flex items-center justify-center space-x-3 mb-4">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-400 to-blue-600 rounded-xl flex items-center justify-center">
              <Globe className="text-white w-6 h-6" />
            </div>
            <span className="text-xl font-bold" style={{ fontFamily: 'var(--font-orbitron)' }}>
              Safelite Global Careers
            </span>
          </div>
          <p className="text-blue-200 mb-4">
            Connecting everyday people with international career opportunities worldwide.
          </p>
          <p className="text-blue-300 text-sm">
            © 2024 Safelite Global Careers. All rights reserved. Premium job matching services.
          </p>
        </div>
      </footer>
    </div>
  );
}
