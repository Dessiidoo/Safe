import { useParams, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { Brain, ArrowLeft, Clock, Users } from "lucide-react";
import { GameInterface } from "@/components/ui/game-interface";

export default function Game() {
  const { gameId } = useParams<{ gameId: string }>();
  
  const { data: game, isLoading: gameLoading } = useQuery({
    queryKey: ["/api/games", gameId],
    enabled: !!gameId,
  });

  const { data: participants, isLoading: participantsLoading } = useQuery({
    queryKey: ["/api/games", gameId, "participants"],
    enabled: !!gameId,
  });

  if (gameLoading) {
    return (
      <div className="min-h-screen">
        <header className="relative z-50 p-4 lg:p-6">
          <nav className="max-w-7xl mx-auto flex items-center justify-between">
            <div className="flex items-center space-x-6">
              <Link href="/">
                <Button variant="ghost" size="sm" data-testid="button-back-home">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back
                </Button>
              </Link>
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-gradient-to-br from-primary to-secondary rounded-xl flex items-center justify-center animate-glow">
                  <Brain className="text-white w-6 h-6" />
                </div>
                <span className="text-2xl font-bold gradient-text" style={{ fontFamily: 'var(--font-orbitron)' }}>
                  MindMystery
                </span>
              </div>
            </div>
          </nav>
        </header>
        
        <div className="px-4 py-8">
          <div className="max-w-7xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 space-y-6">
                <Card className="glass-effect border-white/20">
                  <CardContent className="p-6">
                    <Skeleton className="h-6 w-48 mb-4" />
                    <Skeleton className="h-48 w-full mb-4" />
                    <Skeleton className="h-4 w-full mb-2" />
                    <Skeleton className="h-4 w-3/4" />
                  </CardContent>
                </Card>
              </div>
              <div className="space-y-6">
                <Card className="glass-effect border-white/20">
                  <CardContent className="p-6">
                    <Skeleton className="h-6 w-32 mb-4" />
                    <div className="space-y-3">
                      {Array.from({ length: 4 }).map((_, i) => (
                        <div key={i} className="flex items-center space-x-3">
                          <Skeleton className="w-10 h-10 rounded-full" />
                          <Skeleton className="h-4 flex-1" />
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!game) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="glass-effect border-white/20 max-w-md">
          <CardContent className="p-8 text-center">
            <div className="text-red-400 text-6xl mb-4">⚠️</div>
            <h1 className="text-2xl font-bold mb-4">Game Not Found</h1>
            <p className="text-gray-300 mb-6">
              The game you're looking for doesn't exist or has been completed.
            </p>
            <Link href="/">
              <Button className="bg-primary hover:bg-primary/90" data-testid="button-back-home-error">
                Back to Home
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="relative z-50 p-4 lg:p-6">
        <nav className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-6">
            <Link href="/">
              <Button variant="ghost" size="sm" data-testid="button-back-home">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
            </Link>
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-secondary rounded-xl flex items-center justify-center animate-glow">
                <Brain className="text-white w-6 h-6" />
              </div>
              <span className="text-2xl font-bold gradient-text" style={{ fontFamily: 'var(--font-orbitron)' }}>
                MindMystery
              </span>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2 text-sm">
              <Users className="w-4 h-4" />
              <span data-testid="text-players-count">{game.playersCount}/{game.maxPlayers}</span>
            </div>
            {game.timeRemaining && (
              <div className="flex items-center space-x-2 text-sm bg-danger/20 text-danger px-3 py-1 rounded-full">
                <Clock className="w-4 h-4" />
                <span data-testid="text-time-remaining">
                  {Math.floor(game.timeRemaining / 60)}:{String(game.timeRemaining % 60).padStart(2, '0')}
                </span>
              </div>
            )}
          </div>
        </nav>
      </header>

      {/* Game Status */}
      <div className="px-4 py-2">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-center space-x-4 text-sm">
            <div className={`px-3 py-1 rounded-full ${
              game.status === 'waiting' ? 'bg-accent/20 text-accent' :
              game.status === 'active' ? 'bg-success/20 text-success' :
              'bg-gray-600/20 text-gray-300'
            }`}>
              {game.status === 'waiting' ? 'Waiting for Players' : 
               game.status === 'active' ? 'Game Active' : 'Game Completed'}
            </div>
            <div className="text-gray-400" data-testid="text-game-id">Game ID: {gameId}</div>
          </div>
        </div>
      </div>

      {/* Game Interface */}
      <section className="px-4 py-8">
        <div className="max-w-7xl mx-auto">
          <GameInterface game={game} participants={participants || []} />
        </div>
      </section>
    </div>
  );
}
