import { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Elements, PaymentElement, useElements, useStripe } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { ArrowLeft, CheckCircle, Globe, CreditCard, Shield } from "lucide-react";

// Load Stripe
if (!import.meta.env.VITE_STRIPE_PUBLIC_KEY) {
  throw new Error('Missing required Stripe key: VITE_STRIPE_PUBLIC_KEY');
}
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

const CheckoutForm = ({ tier, onSuccess }: { tier: any; onSuccess: () => void }) => {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [processing, setProcessing] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setProcessing(true);

    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: window.location.origin,
      },
    });

    setProcessing(false);

    if (error) {
      toast({
        title: "Payment Failed",
        description: error.message,
        variant: "destructive",
      });
    } else {
      toast({
        title: "Payment Successful",
        description: "Your subscription is now active!",
      });
      onSuccess();
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <PaymentElement />
      <Button 
        type="submit" 
        disabled={!stripe || processing} 
        className="w-full bg-blue-600 hover:bg-blue-700"
        size="lg"
        data-testid="button-confirm-payment"
      >
        {processing ? (
          <div className="flex items-center space-x-2">
            <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
            <span>Processing...</span>
          </div>
        ) : (
          <>
            <CreditCard className="w-4 h-4 mr-2" />
            Confirm Payment - ${tier.price}/{tier.interval}
          </>
        )}
      </Button>
    </form>
  );
};

export default function Subscribe() {
  const [location] = useLocation();
  const { toast } = useToast();
  const [step, setStep] = useState(1); // 1: retainer, 2: plan selection, 3: payment
  const [selectedTier, setSelectedTier] = useState<any>(null);
  const [retainerClientSecret, setRetainerClientSecret] = useState("");
  const [subscriptionClientSecret, setSubscriptionClientSecret] = useState("");
  const [customerInfo, setCustomerInfo] = useState({ email: "", name: "" });

  const urlParams = new URLSearchParams(location.split('?')[1]);
  const tierParam = urlParams.get('tier');

  const { data: subscriptionTiers, isLoading: tiersLoading } = useQuery({
    queryKey: ["/api/subscription-tiers"],
  });

  useEffect(() => {
    if (subscriptionTiers && tierParam && Array.isArray(subscriptionTiers)) {
      const tier = subscriptionTiers.find((t: any) => t.name.toLowerCase() === tierParam);
      if (tier) {
        setSelectedTier(tier);
        setStep(2); // Skip retainer if coming from a specific tier
      }
    }
  }, [subscriptionTiers, tierParam]);

  const handleRetainerPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const response = await apiRequest("POST", "/api/create-payment-intent", { amount: 99 });
      const data = await response.json();
      setRetainerClientSecret(data.clientSecret);
      setStep(2);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to initialize retainer payment",
        variant: "destructive",
      });
    }
  };

  const handlePlanSelection = async (tier: any) => {
    setSelectedTier(tier);
    
    if (!customerInfo.email || !customerInfo.name) {
      setStep(2.5); // Customer info step
      return;
    }

    try {
      const response = await apiRequest("POST", "/api/create-subscription", {
        email: customerInfo.email,
        name: customerInfo.name,
        tierName: tier.name.toLowerCase()
      });
      const data = await response.json();
      setSubscriptionClientSecret(data.clientSecret);
      setStep(3);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create subscription",
        variant: "destructive",
      });
    }
  };

  const handleCustomerInfoSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedTier) return;

    try {
      const response = await apiRequest("POST", "/api/create-subscription", {
        email: customerInfo.email,
        name: customerInfo.name,
        tierName: selectedTier.name.toLowerCase()
      });
      const data = await response.json();
      setSubscriptionClientSecret(data.clientSecret);
      setStep(3);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create subscription",
        variant: "destructive",
      });
    }
  };

  if (tiersLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-gray-100 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-gray-100">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-blue-100 p-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <Link href="/">
            <Button variant="ghost" className="flex items-center space-x-2" data-testid="button-back-home">
              <ArrowLeft className="w-4 h-4" />
              <span>Back to Home</span>
            </Button>
          </Link>
          
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-blue-800 rounded-lg flex items-center justify-center">
              <Globe className="text-white w-5 h-5" />
            </div>
            <span className="text-xl font-bold text-blue-900" style={{ fontFamily: 'var(--font-orbitron)' }}>
              Safelite Global
            </span>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto p-8">
        {/* Progress Indicator */}
        <div className="mb-8">
          <div className="flex items-center justify-center space-x-4">
            {[1, 2, 3].map((stepNumber) => (
              <div key={stepNumber} className="flex items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold ${
                  stepNumber <= step ? 'bg-blue-600 text-white' : 'bg-gray-300 text-gray-600'
                }`}>
                  {stepNumber < step ? <CheckCircle className="w-4 h-4" /> : stepNumber}
                </div>
                {stepNumber < 3 && (
                  <div className={`w-16 h-1 mx-2 ${stepNumber < step ? 'bg-blue-600' : 'bg-gray-300'}`} />
                )}
              </div>
            ))}
          </div>
          <div className="flex justify-center mt-2">
            <div className="text-sm text-gray-600">
              {step === 1 && "Step 1: Retainer Payment"}
              {step === 2 && "Step 2: Choose Plan"}
              {step === 2.5 && "Step 2: Contact Information"}
              {step === 3 && "Step 3: Complete Payment"}
            </div>
          </div>
        </div>

        {/* Step 1: Retainer Payment */}
        {step === 1 && (
          <Card className="max-w-md mx-auto">
            <CardContent className="p-8 text-center">
              <Shield className="w-16 h-16 text-blue-600 mx-auto mb-6" />
              <h1 className="text-2xl font-bold text-gray-900 mb-4">Secure Your Access</h1>
              <p className="text-gray-600 mb-6">
                Pay the one-time $99 retainer fee to unlock our protected job listings and prevent competitor theft.
              </p>
              
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
                <div className="text-3xl font-bold text-blue-600 mb-2">$99</div>
                <div className="text-sm text-blue-700">One-time retainer fee</div>
              </div>
              
              <form onSubmit={handleRetainerPayment}>
                <Button 
                  type="submit" 
                  className="w-full bg-blue-600 hover:bg-blue-700"
                  size="lg"
                  data-testid="button-pay-retainer"
                >
                  Pay Retainer & Continue
                </Button>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Step 2: Plan Selection */}
        {step === 2 && subscriptionTiers && (
          <div>
            <div className="text-center mb-8">
              <h1 className="text-3xl font-bold text-gray-900 mb-4">Choose Your Plan</h1>
              <p className="text-xl text-gray-600">Select the subscription tier that matches your career goals</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {Array.isArray(subscriptionTiers) && subscriptionTiers.map((tier: any, index: number) => (
                <Card 
                  key={tier.id} 
                  className={`border-2 cursor-pointer transition-all hover:shadow-lg ${
                    selectedTier?.id === tier.id 
                      ? 'border-blue-600 ring-2 ring-blue-600 ring-opacity-20' 
                      : index === 1 
                        ? 'border-blue-400' 
                        : 'border-gray-200'
                  }`}
                  onClick={() => handlePlanSelection(tier)}
                  data-testid={`plan-card-${tier.id}`}
                >
                  {index === 1 && (
                    <div className="bg-blue-600 text-white text-center py-2 text-sm font-bold">
                      MOST POPULAR
                    </div>
                  )}
                  <CardContent className="p-6">
                    <div className="text-center mb-6">
                      <h3 className="text-xl font-bold text-gray-900 mb-2">{tier.name}</h3>
                      <div className="text-3xl font-bold text-blue-600 mb-2">
                        ${tier.price}
                      </div>
                      <div className="text-gray-600">per {tier.interval}</div>
                    </div>
                    
                    <ul className="space-y-2 mb-6">
                      {tier.features.map((feature: string, featureIndex: number) => (
                        <li key={featureIndex} className="flex items-center space-x-2 text-sm">
                          <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                    
                    <Button 
                      className={`w-full ${
                        selectedTier?.id === tier.id 
                          ? 'bg-blue-600 hover:bg-blue-700' 
                          : 'bg-gray-100 hover:bg-gray-200 text-gray-900'
                      }`}
                      data-testid={`button-select-${tier.id}`}
                    >
                      Select {tier.name}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Step 2.5: Customer Information */}
        {step === 2.5 && (
          <Card className="max-w-md mx-auto">
            <CardContent className="p-8">
              <h1 className="text-2xl font-bold text-gray-900 mb-6 text-center">Contact Information</h1>
              
              <form onSubmit={handleCustomerInfoSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="email">Email Address</Label>
                  <Input
                    id="email"
                    type="email"
                    value={customerInfo.email}
                    onChange={(e) => setCustomerInfo({ ...customerInfo, email: e.target.value })}
                    required
                    data-testid="input-email"
                  />
                </div>
                
                <div>
                  <Label htmlFor="name">Full Name</Label>
                  <Input
                    id="name"
                    type="text"
                    value={customerInfo.name}
                    onChange={(e) => setCustomerInfo({ ...customerInfo, name: e.target.value })}
                    required
                    data-testid="input-name"
                  />
                </div>
                
                <Button 
                  type="submit" 
                  className="w-full bg-blue-600 hover:bg-blue-700"
                  size="lg"
                  data-testid="button-continue-payment"
                >
                  Continue to Payment
                </Button>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Step 3: Payment */}
        {step === 3 && subscriptionClientSecret && selectedTier && (
          <Card className="max-w-md mx-auto">
            <CardContent className="p-8">
              <div className="text-center mb-6">
                <h1 className="text-2xl font-bold text-gray-900 mb-2">Complete Payment</h1>
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <div className="text-lg font-bold text-blue-600">{selectedTier.name} Plan</div>
                  <div className="text-2xl font-bold text-blue-600">
                    ${selectedTier.price}/{selectedTier.interval}
                  </div>
                </div>
              </div>
              
              <Elements stripe={stripePromise} options={{ clientSecret: subscriptionClientSecret }}>
                <CheckoutForm 
                  tier={selectedTier} 
                  onSuccess={() => {
                    toast({
                      title: "Success!",
                      description: "Your subscription is now active. Welcome to Safelite Global Careers!",
                    });
                    setTimeout(() => {
                      window.location.href = "/dashboard";
                    }, 2000);
                  }} 
                />
              </Elements>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}