import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { Brain, ArrowLeft, Play } from "lucide-react";
import { CharacterCard } from "@/components/ui/character-card";

export default function CharacterSelect() {
  const [selectedCharacter, setSelectedCharacter] = useState<string | null>(null);
  
  const { data: characters, isLoading } = useQuery({
    queryKey: ["/api/characters"],
  });

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="relative z-50 p-4 lg:p-6">
        <nav className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-6">
            <Link href="/">
              <Button variant="ghost" size="sm" data-testid="button-back-home">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
            </Link>
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-primary to-secondary rounded-xl flex items-center justify-center animate-glow">
                <Brain className="text-white w-6 h-6" />
              </div>
              <span className="text-2xl font-bold gradient-text" style={{ fontFamily: 'var(--font-orbitron)' }}>
                MindMystery
              </span>
            </div>
          </div>
          
          <div className="hidden md:flex items-center space-x-4">
            {selectedCharacter && (
              <Button 
                size="lg" 
                className="bg-gradient-to-r from-primary to-secondary hover:from-primary/90 hover:to-secondary/90"
                data-testid="button-continue-game"
              >
                <Play className="mr-2 w-4 h-4" />
                Continue
              </Button>
            )}
          </div>
        </nav>
      </header>

      {/* Character Selection */}
      <section className="px-4 py-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-4xl lg:text-5xl font-bold mb-6" style={{ fontFamily: 'var(--font-orbitron)' }}>
              Choose Your <span className="gradient-text">Character</span>
            </h1>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Each character brings unique abilities to the mystery-solving experience. 
              Select the one that matches your problem-solving style.
            </p>
          </div>

          {/* Character Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {isLoading ? (
              Array.from({ length: 8 }).map((_, i) => (
                <Card key={i} className="glass-effect border-white/20">
                  <CardContent className="p-6">
                    <Skeleton className="w-24 h-24 rounded-full mx-auto mb-4" />
                    <Skeleton className="h-6 w-32 mx-auto mb-2" />
                    <Skeleton className="h-4 w-full mb-4" />
                    <Skeleton className="h-4 w-3/4 mb-2" />
                    <Skeleton className="h-4 w-2/3" />
                  </CardContent>
                </Card>
              ))
            ) : (
              characters?.map((character) => (
                <CharacterCard
                  key={character.id}
                  character={character}
                  isSelected={selectedCharacter === character.id}
                  onSelect={() => setSelectedCharacter(character.id)}
                />
              ))
            )}
          </div>

          {/* Selected Character Details */}
          {selectedCharacter && (
            <Card className="glass-effect border-white/20 max-w-4xl mx-auto mb-8">
              <CardContent className="p-8">
                <div className="text-center mb-6">
                  <h2 className="text-2xl font-bold mb-4" style={{ fontFamily: 'var(--font-orbitron)' }}>
                    You selected: <span className="gradient-text">
                      {characters?.find(c => c.id === selectedCharacter)?.name}
                    </span>
                  </h2>
                  <p className="text-lg text-gray-300">
                    {characters?.find(c => c.id === selectedCharacter)?.description}
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="text-lg font-semibold mb-4">Special Abilities</h3>
                    <div className="space-y-3">
                      {Array.isArray(characters?.find(c => c.id === selectedCharacter)?.abilities) && 
                        characters?.find(c => c.id === selectedCharacter)?.abilities.map((ability: any, index: number) => (
                        <div key={index} className="flex items-start space-x-3 p-3 bg-white/10 rounded-lg">
                          <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0 mt-1">
                            {ability.icon === 'search' && <span>🔍</span>}
                            {ability.icon === 'lightbulb' && <span>💡</span>}
                            {ability.icon === 'chart-line' && <span>📈</span>}
                            {ability.icon === 'brain' && <span>🧠</span>}
                            {ability.icon === 'eye' && <span>👁️</span>}
                            {ability.icon === 'heart' && <span>❤️</span>}
                            {ability.icon === 'code' && <span>💻</span>}
                            {ability.icon === 'shield-alt' && <span>🛡️</span>}
                          </div>
                          <div>
                            <div className="font-medium">{ability.name}</div>
                            <div className="text-sm text-gray-400">{ability.description}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold mb-4">Game Tips</h3>
                    <div className="space-y-3">
                      <div className="p-3 bg-success/20 rounded-lg">
                        <div className="text-success font-medium">✓ Team Strategy</div>
                        <div className="text-sm text-gray-300">
                          Combine your abilities with teammates for maximum effectiveness
                        </div>
                      </div>
                      <div className="p-3 bg-accent/20 rounded-lg">
                        <div className="text-accent font-medium">⚡ Quick Actions</div>
                        <div className="text-sm text-gray-300">
                          Use character abilities early and often during investigations
                        </div>
                      </div>
                      <div className="p-3 bg-sky/20 rounded-lg">
                        <div className="text-sky font-medium">🎯 Focus Areas</div>
                        <div className="text-sm text-gray-300">
                          Concentrate on clues that match your character's strengths
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Action Buttons */}
          <div className="text-center space-y-4">
            {selectedCharacter ? (
              <div className="space-y-4">
                <Button 
                  size="lg" 
                  className="bg-gradient-to-r from-primary to-secondary hover:from-primary/90 hover:to-secondary/90 animate-glow px-12 py-4 text-lg"
                  data-testid="button-start-mystery"
                >
                  <Play className="mr-2 w-5 h-5" />
                  Start Mystery
                </Button>
                <div className="text-sm text-gray-400">
                  You'll be matched with other players or you can create a new game
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="text-lg text-gray-400">Select a character to continue</div>
                <div className="text-sm text-gray-500">
                  Each character offers a unique gameplay experience
                </div>
              </div>
            )}
          </div>

          {/* Character Comparison */}
          <div className="mt-16">
            <h2 className="text-2xl font-bold text-center mb-8" style={{ fontFamily: 'var(--font-orbitron)' }}>
              Character Comparison
            </h2>
            <Card className="glass-effect border-white/20">
              <CardContent className="p-6">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-white/20">
                        <th className="text-left p-3">Character</th>
                        <th className="text-left p-3">Investigation</th>
                        <th className="text-left p-3">Analysis</th>
                        <th className="text-left p-3">Intuition</th>
                        <th className="text-left p-3">Technology</th>
                      </tr>
                    </thead>
                    <tbody>
                      {characters?.map((character, index) => (
                        <tr key={character.id} className={`${index % 2 === 0 ? 'bg-white/5' : ''}`}>
                          <td className="p-3 font-medium">{character.name}</td>
                          <td className="p-3">
                            {character.name === 'Detective' ? '⭐⭐⭐⭐⭐' : 
                             character.name === 'Analyst' ? '⭐⭐⭐' : 
                             character.name === 'Intuitive' ? '⭐⭐' : '⭐⭐'}
                          </td>
                          <td className="p-3">
                            {character.name === 'Analyst' ? '⭐⭐⭐⭐⭐' : 
                             character.name === 'Detective' ? '⭐⭐⭐⭐' : 
                             character.name === 'Technician' ? '⭐⭐⭐' : '⭐⭐'}
                          </td>
                          <td className="p-3">
                            {character.name === 'Intuitive' ? '⭐⭐⭐⭐⭐' : 
                             character.name === 'Detective' ? '⭐⭐⭐' : 
                             character.name === 'Analyst' ? '⭐⭐' : '⭐⭐'}
                          </td>
                          <td className="p-3">
                            {character.name === 'Technician' ? '⭐⭐⭐⭐⭐' : 
                             character.name === 'Analyst' ? '⭐⭐⭐⭐' : 
                             character.name === 'Detective' ? '⭐⭐' : '⭐'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}
