import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Search, Microscope, Users, Lightbulb } from "lucide-react";

export function InvestigationTools() {
  const tools = [
    {
      id: 'examine',
      name: 'Examine',
      icon: Search,
      description: 'Look for physical evidence and clues',
      color: 'bg-primary/20 hover:bg-primary/30 text-primary'
    },
    {
      id: 'analyze', 
      name: 'Analyze',
      icon: Microscope,
      description: 'Process and study collected evidence',
      color: 'bg-secondary/20 hover:bg-secondary/30 text-secondary'
    },
    {
      id: 'interview',
      name: 'Interview', 
      icon: Users,
      description: 'Question witnesses and suspects',
      color: 'bg-success/20 hover:bg-success/30 text-success'
    },
    {
      id: 'deduce',
      name: 'Deduce',
      icon: Lightbulb,
      description: 'Connect clues and form theories',
      color: 'bg-accent/20 hover:bg-accent/30 text-accent'
    }
  ];

  const handleToolClick = (toolId: string) => {
    // TODO: Implement investigation tool functionality
    console.log(`Using tool: ${toolId}`);
  };

  return (
    <Card className="glass-effect border-white/20">
      <CardContent className="p-6">
        <h3 className="text-xl font-semibold mb-4">Investigation Tools</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {tools.map((tool) => {
            const IconComponent = tool.icon;
            return (
              <Button
                key={tool.id}
                onClick={() => handleToolClick(tool.id)}
                className={`p-4 h-auto flex flex-col items-center space-y-2 transition-colors ${tool.color}`}
                variant="outline"
                data-testid={`button-tool-${tool.id}`}
              >
                <IconComponent className="w-8 h-8" />
                <div className="text-sm font-medium">{tool.name}</div>
              </Button>
            );
          })}
        </div>
        
        <div className="mt-4 p-3 bg-white/5 rounded-lg">
          <div className="text-sm text-gray-300">
            <strong>Tip:</strong> Different characters excel at different investigation methods. 
            Use your character's abilities to maximize effectiveness!
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
