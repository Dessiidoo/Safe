import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Send } from "lucide-react";

interface ChatMessage {
  id: string;
  userId: string;
  username: string;
  message: string;
  timestamp: Date;
}

interface TeamChatProps {
  messages: ChatMessage[];
  gameId: string;
}

export function TeamChat({ messages, gameId }: TeamChatProps) {
  const [newMessage, setNewMessage] = useState("");

  const handleSendMessage = () => {
    if (newMessage.trim()) {
      // TODO: Send message to backend
      console.log('Sending message:', newMessage);
      setNewMessage("");
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSendMessage();
    }
  };

  // Mock messages for demo
  const mockMessages = [
    {
      id: "1",
      userId: "detective-alex",
      username: "Detective Alex",
      message: "The fingerprints don't match any staff records",
      timestamp: new Date(Date.now() - 300000)
    },
    {
      id: "2", 
      userId: "technician-sam",
      username: "Technician Sam",
      message: "Found a 15-minute gap in security footage at 3:47 AM",
      timestamp: new Date(Date.now() - 180000)
    },
    {
      id: "3",
      userId: "intuitive-jordan", 
      username: "Intuitive Jordan",
      message: "Something feels off about the maintenance timing...",
      timestamp: new Date(Date.now() - 120000)
    }
  ];

  const allMessages = messages.length > 0 ? messages : mockMessages;

  return (
    <Card className="glass-effect border-white/20">
      <CardContent className="p-6">
        <h3 className="text-xl font-semibold mb-4">Team Chat</h3>
        
        <ScrollArea className="h-64 mb-4 pr-4" data-testid="chat-messages">
          <div className="space-y-3">
            {allMessages.map((message) => (
              <div key={message.id} className="text-sm" data-testid={`message-${message.id}`}>
                <div className="flex items-start space-x-2">
                  <span className="font-medium text-primary shrink-0">
                    {message.username}:
                  </span>
                  <span className="text-gray-300 break-words">
                    {message.message}
                  </span>
                </div>
                <div className="text-xs text-gray-500 mt-1">
                  {message.timestamp.toLocaleTimeString()}
                </div>
              </div>
            ))}
            {allMessages.length === 0 && (
              <div className="text-gray-400 text-center py-8">
                No messages yet. Start the conversation!
              </div>
            )}
          </div>
        </ScrollArea>
        
        <div className="flex space-x-2">
          <Input 
            type="text" 
            placeholder="Type your message..." 
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            className="flex-1 bg-gray-800 text-white border-gray-700"
            data-testid="input-chat-message"
          />
          <Button 
            onClick={handleSendMessage}
            className="bg-primary hover:bg-primary/90"
            disabled={!newMessage.trim()}
            data-testid="button-send-message"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
