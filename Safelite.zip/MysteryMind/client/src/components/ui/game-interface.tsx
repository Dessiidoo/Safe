import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { TeamChat } from "./team-chat";
import { InvestigationTools } from "./investigation-tools";
import type { Game, GameParticipant } from "@shared/schema";
import { Clock, Search, Microscope, Users, Lightbulb } from "lucide-react";

interface GameInterfaceProps {
  game: Game;
  participants: GameParticipant[];
}

export function GameInterface({ game, participants }: GameInterfaceProps) {
  const foundClues = Array.isArray(game.foundClues) ? game.foundClues : [];
  const chatMessages = Array.isArray(game.chatMessages) ? game.chatMessages : [];

  // Mock mystery data - in real app this would come from the mystery
  const mockMystery = {
    title: "The Vanishing Artifact",
    description: "A priceless artifact has disappeared from the Metropolitan Museum. Security cameras show no signs of forced entry, yet the display case stands empty. Your team must work together to uncover the truth before the trail goes cold.",
    imageUrl: "https://images.unsplash.com/photo-1551816230-ef5deaed4a26?w=800&h=400&fit=crop",
    totalClues: 12,
    totalSuspects: 5
  };

  const evidenceProgress = (foundClues.length / mockMystery.totalClues) * 100;
  const suspectsProgress = 60; // Mock data
  const caseProgress = 45; // Mock data

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Main Game Area */}
      <div className="lg:col-span-2 space-y-6">
        {/* Current Mystery */}
        <Card className="glass-effect border-white/20">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-semibold" data-testid="text-mystery-title">
                Current Mystery: {mockMystery.title}
              </h3>
              {game.timeRemaining && (
                <div className="bg-danger/20 text-danger px-3 py-1 rounded-full text-sm flex items-center">
                  <Clock className="w-4 h-4 mr-1" />
                  <span data-testid="text-time-remaining">
                    {Math.floor(game.timeRemaining / 60)}:{String(game.timeRemaining % 60).padStart(2, '0')}
                  </span>
                </div>
              )}
            </div>
            
            <img 
              src={mockMystery.imageUrl} 
              alt="Mystery scene" 
              className="w-full h-48 object-cover rounded-lg mb-4"
              data-testid="image-mystery-scene"
            />
            
            <p className="text-gray-300 mb-4" data-testid="text-mystery-description">
              {mockMystery.description}
            </p>
            
            {/* Clues Found */}
            <div className="space-y-3">
              <h4 className="font-semibold">Clues Discovered</h4>
              {foundClues.length > 0 ? (
                foundClues.map((clue: any, index: number) => (
                  <div 
                    key={index}
                    className="flex items-center justify-between p-3 bg-success/20 rounded-lg"
                    data-testid={`clue-${index}`}
                  >
                    <div className="flex items-center">
                      <span className="text-success mr-3">✓</span>
                      <span>{clue.text || `Clue #${index + 1}`}</span>
                    </div>
                    <span className="text-xs text-gray-400">{clue.discoveredBy || 'Team'}</span>
                  </div>
                ))
              ) : (
                <div className="text-gray-400 text-sm p-3 bg-gray-800/20 rounded-lg">
                  No clues discovered yet. Start investigating!
                </div>
              )}
            </div>
          </CardContent>
        </Card>
        
        {/* Investigation Tools */}
        <InvestigationTools />
      </div>
      
      {/* Sidebar */}
      <div className="space-y-6">
        {/* Team Members */}
        <Card className="glass-effect border-white/20">
          <CardContent className="p-6">
            <h3 className="text-xl font-semibold mb-4" data-testid="text-team-members">
              Team Members ({participants.length}/{game.maxPlayers})
            </h3>
            <div className="space-y-3">
              {participants.length > 0 ? (
                participants.map((participant) => (
                  <div 
                    key={participant.id}
                    className="flex items-center space-x-3"
                    data-testid={`participant-${participant.id}`}
                  >
                    <img 
                      src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face" 
                      alt="Player avatar" 
                      className="w-10 h-10 rounded-full object-cover ring-2 ring-primary" 
                    />
                    <div className="flex-1">
                      <div className="font-medium">Player {participant.id.slice(0, 8)}</div>
                      <div className="text-sm text-gray-400">
                        {participant.isOnline ? 'Online' : 'Offline'}
                      </div>
                    </div>
                    <div className={`w-3 h-3 rounded-full ${
                      participant.isOnline ? 'bg-success' : 'bg-gray-600'
                    }`}></div>
                  </div>
                ))
              ) : (
                <div className="text-gray-400 text-sm">
                  Waiting for players to join...
                </div>
              )}
            </div>
          </CardContent>
        </Card>
        
        {/* Team Chat */}
        <TeamChat messages={chatMessages} gameId={game.id} />
        
        {/* Progress */}
        <Card className="glass-effect border-white/20">
          <CardContent className="p-6">
            <h3 className="text-xl font-semibold mb-4">Case Progress</h3>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Evidence Collected</span>
                  <span data-testid="text-evidence-progress">{foundClues.length}/{mockMystery.totalClues}</span>
                </div>
                <Progress value={evidenceProgress} className="h-2" />
              </div>
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Suspects Interviewed</span>
                  <span data-testid="text-suspects-progress">3/{mockMystery.totalSuspects}</span>
                </div>
                <Progress value={suspectsProgress} className="h-2" />
              </div>
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span>Case Completion</span>
                  <span data-testid="text-case-progress">{caseProgress}%</span>
                </div>
                <Progress value={caseProgress} className="h-2" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Game Actions */}
        {game.status === 'waiting' && (
          <Card className="glass-effect border-white/20">
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold mb-4">Game Actions</h3>
              <div className="space-y-3">
                <Button 
                  className="w-full bg-primary hover:bg-primary/90"
                  data-testid="button-start-game"
                >
                  Start Game
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full border-white/20"
                  data-testid="button-leave-game"
                >
                  Leave Game
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
