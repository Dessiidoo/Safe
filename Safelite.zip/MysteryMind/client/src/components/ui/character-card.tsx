import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import type { Character } from "@shared/schema";

interface CharacterCardProps {
  character: Character;
  isSelected: boolean;
  onSelect: () => void;
}

export function CharacterCard({ character, isSelected, onSelect }: CharacterCardProps) {
  return (
    <Card 
      className={`glass-effect border-white/20 hover:bg-white/20 transition-all transform hover:scale-105 cursor-pointer group ${
        isSelected ? 'ring-2 ring-primary bg-white/20' : ''
      }`}
      onClick={onSelect}
      data-testid={`character-card-${character.id}`}
    >
      <CardContent className="p-6">
        <div className="relative mb-4">
          <img 
            src={character.avatarUrl || "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face"} 
            alt={`${character.name} character`} 
            className={`w-24 h-24 rounded-full mx-auto object-cover ring-4 transition-all ${
              isSelected ? 'ring-primary' : 'ring-primary/50 group-hover:ring-primary'
            }`}
          />
          {isSelected && (
            <div className="absolute -top-2 -right-2 w-6 h-6 bg-primary rounded-full flex items-center justify-center">
              <span className="text-white text-xs font-bold">✓</span>
            </div>
          )}
        </div>
        
        <h3 className="text-xl font-semibold mb-2 text-center" data-testid={`text-character-name-${character.id}`}>
          {character.name}
        </h3>
        
        <p className="text-gray-300 text-sm mb-4 text-center" data-testid={`text-character-description-${character.id}`}>
          {character.description}
        </p>
        
        <div className="space-y-2 mb-4">
          {Array.isArray(character.abilities) && character.abilities.slice(0, 2).map((ability: any, index: number) => (
            <div key={index} className="flex items-center text-sm" data-testid={`ability-${character.id}-${index}`}>
              <div className="w-4 h-4 mr-2 flex items-center justify-center">
                {ability.icon === 'search' && <span className="text-primary">🔍</span>}
                {ability.icon === 'lightbulb' && <span className="text-accent">💡</span>}
                {ability.icon === 'chart-line' && <span className="text-success">📈</span>}
                {ability.icon === 'brain' && <span className="text-accent">🧠</span>}
                {ability.icon === 'eye' && <span className="text-secondary">👁️</span>}
                {ability.icon === 'heart' && <span className="text-accent">❤️</span>}
                {ability.icon === 'code' && <span className="text-sky">💻</span>}
                {ability.icon === 'shield-alt' && <span className="text-accent">🛡️</span>}
              </div>
              <span>{ability.name}</span>
            </div>
          ))}
        </div>

        <Button 
          className={`w-full ${
            isSelected 
              ? 'bg-primary hover:bg-primary/90' 
              : 'bg-white/10 hover:bg-white/20 border-white/20'
          }`}
          variant={isSelected ? 'default' : 'outline'}
          onClick={(e) => {
            e.stopPropagation();
            onSelect();
          }}
          data-testid={`button-select-${character.id}`}
        >
          {isSelected ? 'Selected' : 'Select Character'}
        </Button>
      </CardContent>
    </Card>
  );
}
