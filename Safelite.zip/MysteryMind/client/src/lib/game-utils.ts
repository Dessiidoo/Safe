import type { Character, Game, Mystery } from "@shared/schema";

export function getCharacterByType(characters: Character[], type: string): Character | undefined {
  return characters.find(char => char.id === type);
}

export function calculateGameProgress(game: Game, mystery: Mystery): {
  evidenceProgress: number;
  overallProgress: number;
} {
  const foundClues = Array.isArray(game.foundClues) ? game.foundClues : [];
  const totalClues = Array.isArray(mystery.clues) ? mystery.clues.length : 0;
  
  const evidenceProgress = totalClues > 0 ? (foundClues.length / totalClues) * 100 : 0;
  
  // Overall progress includes evidence, interviews, and deductions
  const overallProgress = Math.min(evidenceProgress * 0.7 + 30, 100); // Simplified calculation
  
  return {
    evidenceProgress,
    overallProgress
  };
}

export function formatTimeRemaining(seconds: number): string {
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;
  return `${minutes}:${String(remainingSeconds).padStart(2, '0')}`;
}

export function getCharacterAbilityIcon(iconName: string): string {
  const iconMap: Record<string, string> = {
    'search': '🔍',
    'lightbulb': '💡',
    'chart-line': '📈',
    'brain': '🧠',
    'eye': '👁️',
    'heart': '❤️',
    'code': '💻',
    'shield-alt': '🛡️'
  };
  
  return iconMap[iconName] || '⚡';
}

export function generateGameId(): string {
  return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
}

export function getGameStatusColor(status: string): string {
  switch (status) {
    case 'waiting':
      return 'bg-accent/20 text-accent';
    case 'active':
      return 'bg-success/20 text-success';
    case 'completed':
      return 'bg-gray-600/20 text-gray-300';
    default:
      return 'bg-gray-600/20 text-gray-300';
  }
}

export function shouldShowJoinButton(game: Game): boolean {
  return game.status === 'waiting' && game.playersCount < game.maxPlayers;
}

export function canUseInvestigationTool(character: Character, toolId: string): boolean {
  if (!Array.isArray(character.abilities)) return true;
  
  // Simple logic - detectives are good at examining, analysts at analyzing, etc.
  const characterToolMapping: Record<string, string[]> = {
    'detective': ['examine', 'interview'],
    'analyst': ['analyze', 'deduce'],
    'intuitive': ['interview', 'deduce'], 
    'technician': ['examine', 'analyze']
  };
  
  const preferredTools = characterToolMapping[character.id] || [];
  return preferredTools.length === 0 || preferredTools.includes(toolId);
}

export function generateMockClue(index: number): any {
  const clueTemplates = [
    "Fingerprint analysis reveals unknown prints on the case",
    "Security footage gap detected during maintenance window", 
    "Suspicious timing of maintenance request",
    "Limited staff had after-hours access",
    "Recent increase in artifact insurance",
    "Unusual visitor log entries before the incident",
    "Missing security guard shift report",
    "Tampered lock mechanism discovered"
  ];
  
  return {
    id: `clue-${index}`,
    text: clueTemplates[index % clueTemplates.length],
    discoveredBy: null,
    difficulty: Math.floor(Math.random() * 5) + 1
  };
}
