import { type User, type InsertUser, type JobApplication, type InsertJobApplication, type JobListing, type InsertJobListing, type SubscriptionTier } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User | undefined>;
  
  // Job Application methods
  createJobApplication(application: InsertJobApplication): Promise<JobApplication>;
  getJobApplication(id: string): Promise<JobApplication | undefined>;
  getJobApplicationsByUser(userId: string): Promise<JobApplication[]>;
  updateJobApplication(id: string, updates: Partial<JobApplication>): Promise<JobApplication | undefined>;
  
  // Job Listing methods
  getJobListings(tier?: string): Promise<JobListing[]>;
  getJobListing(id: string): Promise<JobListing | undefined>;
  createJobListing(listing: InsertJobListing): Promise<JobListing>;
  updateJobListing(id: string, updates: Partial<JobListing>): Promise<JobListing | undefined>;
  getFeaturedJobs(): Promise<JobListing[]>;
  
  // Subscription methods
  getSubscriptionTiers(): Promise<SubscriptionTier[]>;
  getSubscriptionTier(name: string): Promise<SubscriptionTier | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private jobApplications: Map<string, JobApplication> = new Map();
  private jobListings: Map<string, JobListing> = new Map();
  private subscriptionTiers: Map<string, SubscriptionTier> = new Map();

  constructor() {
    this.initializeDefaultData();
  }

  private initializeDefaultData() {
    // Initialize subscription tiers
    const tierData: SubscriptionTier[] = [
      {
        id: "basic",
        name: "Basic",
        price: "500",
        currency: "USD",
        interval: "month",
        features: [
          "Access to basic job listings",
          "Country filter",
          "Email notifications",
          "Basic support"
        ],
        jobsPerMonth: 20,
        isActive: true
      },
      {
        id: "premium", 
        name: "Premium",
        price: "2000",
        currency: "USD",
        interval: "month",
        features: [
          "All basic features",
          "Access to premium job listings",
          "Priority job matching",
          "Advanced filters",
          "Direct employer contact",
          "Resume optimization",
          "Interview preparation"
        ],
        jobsPerMonth: 100,
        isActive: true
      },
      {
        id: "vip",
        name: "VIP",
        price: "5000", 
        currency: "USD",
        interval: "month",
        features: [
          "All premium features",
          "Exclusive VIP job listings",
          "Personal job matching consultant", 
          "Visa assistance",
          "Relocation support",
          "Priority customer support",
          "Custom job alerts"
        ],
        jobsPerMonth: 500,
        isActive: true
      }
    ];

    tierData.forEach(tier => this.subscriptionTiers.set(tier.name.toLowerCase(), tier));

    // Initialize sample job listings
    const jobData: JobListing[] = [
      {
        id: "job-1",
        title: "Customer Service Representative",
        company: "Global Tech Solutions",
        location: "Toronto, ON",
        country: "Canada",
        description: "Join our international customer service team serving clients worldwide. No experience required - we provide full training.",
        requirements: ["High school diploma", "Excellent English communication", "Computer literacy", "Customer service mindset"],
        benefits: ["Health insurance", "Visa sponsorship", "Training provided", "Career advancement"],
        salary: "$35,000 - $42,000 CAD",
        jobType: "full-time",
        experienceLevel: "entry",
        visaSponsorship: true,
        remote: false,
        featured: true,
        requiredTier: "basic",
        isActive: true,
        externalUrl: "https://example-jobs.com/1",
        createdAt: new Date(),
        updatedAt: new Date()
      },
      {
        id: "job-2", 
        title: "Hotel Front Desk Agent",
        company: "International Resort Group",
        location: "Sydney, NSW",
        country: "Australia", 
        description: "Work in luxury hotels across Australia. Perfect for those seeking hospitality experience with visa support.",
        requirements: ["Basic English proficiency", "Friendly personality", "Willingness to learn", "Flexible schedule"],
        benefits: ["Accommodation assistance", "Visa sponsorship", "Travel opportunities", "Training programs"],
        salary: "$45,000 - $52,000 AUD",
        jobType: "full-time",
        experienceLevel: "entry", 
        visaSponsorship: true,
        remote: false,
        featured: false,
        requiredTier: "premium",
        isActive: true,
        externalUrl: "https://example-jobs.com/2",
        createdAt: new Date(),
        updatedAt: new Date()
      }
    ];

    jobData.forEach(job => this.jobListings.set(job.id, job));
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = {
      ...insertUser,
      id,
      subscriptionTier: null,
      stripeCustomerId: null,
      stripeSubscriptionId: null,
      hasRetainerAccess: false,
      retainerPaid: false,
      profileCompleted: false,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates, updatedAt: new Date() };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Job Application methods
  async createJobApplication(insertApplication: InsertJobApplication): Promise<JobApplication> {
    const id = randomUUID();
    const application: JobApplication = {
      ...insertApplication,
      id,
      status: "pending",
      createdAt: new Date()
    };
    this.jobApplications.set(id, application);
    return application;
  }

  async getJobApplication(id: string): Promise<JobApplication | undefined> {
    return this.jobApplications.get(id);
  }

  async getJobApplicationsByUser(userId: string): Promise<JobApplication[]> {
    return Array.from(this.jobApplications.values()).filter(app => app.userId === userId);
  }

  async updateJobApplication(id: string, updates: Partial<JobApplication>): Promise<JobApplication | undefined> {
    const application = this.jobApplications.get(id);
    if (!application) return undefined;
    
    const updatedApplication = { ...application, ...updates };
    this.jobApplications.set(id, updatedApplication);
    return updatedApplication;
  }

  // Job Listing methods
  async getJobListings(tier?: string): Promise<JobListing[]> {
    const allJobs = Array.from(this.jobListings.values()).filter(job => job.isActive);
    if (!tier) return allJobs;
    
    // Filter based on tier access
    if (tier === 'basic') {
      return allJobs.filter(job => job.requiredTier === 'basic');
    } else if (tier === 'premium') {
      return allJobs.filter(job => job.requiredTier === 'basic' || job.requiredTier === 'premium');
    } else if (tier === 'vip') {
      return allJobs; // VIP can see all jobs
    }
    
    return [];
  }

  async getJobListing(id: string): Promise<JobListing | undefined> {
    return this.jobListings.get(id);
  }

  async createJobListing(insertListing: InsertJobListing): Promise<JobListing> {
    const id = randomUUID();
    const listing: JobListing = {
      ...insertListing,
      id,
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.jobListings.set(id, listing);
    return listing;
  }

  async updateJobListing(id: string, updates: Partial<JobListing>): Promise<JobListing | undefined> {
    const listing = this.jobListings.get(id);
    if (!listing) return undefined;
    
    const updatedListing = { ...listing, ...updates, updatedAt: new Date() };
    this.jobListings.set(id, updatedListing);
    return updatedListing;
  }

  async getFeaturedJobs(): Promise<JobListing[]> {
    return Array.from(this.jobListings.values()).filter(job => job.featured && job.isActive);
  }

  // Subscription methods
  async getSubscriptionTiers(): Promise<SubscriptionTier[]> {
    return Array.from(this.subscriptionTiers.values()).filter(tier => tier.isActive);
  }

  async getSubscriptionTier(name: string): Promise<SubscriptionTier | undefined> {
    return this.subscriptionTiers.get(name.toLowerCase());
  }
}

export const storage = new MemStorage();
